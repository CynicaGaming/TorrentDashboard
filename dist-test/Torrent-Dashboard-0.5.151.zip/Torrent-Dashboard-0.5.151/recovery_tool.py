#!/usr/bin/env python3
"""Legacy recovery launcher; maintained code lives under src/."""
from pathlib import Path
import sys

_SRC = Path(__file__).resolve().parent / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from torrent_dashboard.recovery_tool import main

if __name__ == "__main__":
    raise SystemExit(main())
