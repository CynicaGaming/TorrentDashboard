#!/usr/bin/env python3
"""Legacy source-update compatibility launcher; maintained code lives under src/."""
from pathlib import Path
import sys

_SRC = Path(__file__).resolve().parent / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

VERSION = "0.5.147"
from torrent_dashboard.dashboard import main

if __name__ == "__main__":
    raise SystemExit(main())
