"""Restricted command grammar for the authenticated Torrent Dashboard console."""
from __future__ import annotations

import shlex

RECOVERY_COMMAND_MAX_CHARS = 4096
SAFE_TORRENT_ACTIONS = frozenset({"start", "stop", "recheck", "reannounce"})


def parse_recovery_command(value):
    raw = str(value or "").strip()
    if not raw:
        raise RuntimeError("Enter a console command")
    if len(raw) > RECOVERY_COMMAND_MAX_CHARS:
        raise RuntimeError("Console command is too long")
    if "\n" in raw or "\r" in raw:
        raise RuntimeError("Run one console command at a time")
    try:
        tokens = shlex.split(raw, posix=True)
    except ValueError as exc:
        raise RuntimeError(f"Invalid console command: {exc}") from exc
    if not tokens:
        raise RuntimeError("Enter a console command")
    return tokens


def recovery_help_text(is_admin=False):
    common = """Torrent Dashboard Console

Available to your account:
  help
  status
  client list
  integration list
  torrent list [client-id]
  jellyfin list <integration-id>
  update status
  update check
  update repo
"""
    if is_admin:
        common += """
Administrator diagnostics:
  config show
  client test <client-id>
  integration test <integration-id>
  users
  events [limit]

Administrator actions:
  torrent action <client-id> <start|stop|recheck|reannounce> <hash|all>
  jellyfin start <integration-id> <task-id>
  jellyfin stop <integration-id> <task-id>
  update repo <owner/repository|default>
  update download
  update install [version] --confirm
  update apply --confirm
"""
    else:
        common += """
Your session is read-only. Administrator-only diagnostics and actions are hidden.
"""
    common += """
Browser-local recovery:
  frontend clear-cache
  clear
  reload

This is not an operating-system shell. Only the commands shown for your role are accepted."""
    return common
