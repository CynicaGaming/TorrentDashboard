"""Torrent Dashboard application package."""

__version__ = "0.5.147"
